
Up to February 2024, this code used XML.

Here is a walkthrough that covers this version of the assignment:

https://www.youtube.com/watch?v=UGe7X_L-lHc

If you are using the original tracks.py that is reading XML, you can 
export your own Library.xml from iTunes 

File -> Library -> Export Library

Make sure it is in the correct folder.   Of course iTunes might change its
UI and/or export format any time - so good luck :)
